package com.aquarium.dto.period;

import java.time.LocalDate;

public record PeriodEndDTO(LocalDate end) {}
