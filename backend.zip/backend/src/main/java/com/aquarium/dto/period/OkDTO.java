package com.aquarium.dto.period;

public record OkDTO(Boolean ok, int newId) {
}
