package com.aquarium.dto.period;

public record PeriodFinancialDTO(double expense, double income, double benefit, boolean closed) {
}
