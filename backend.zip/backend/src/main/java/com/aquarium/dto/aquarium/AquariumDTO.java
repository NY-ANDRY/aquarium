package com.aquarium.dto.aquarium;

public record AquariumDTO(
        Long id,
        String name,
        int nb_poisson) {
}
