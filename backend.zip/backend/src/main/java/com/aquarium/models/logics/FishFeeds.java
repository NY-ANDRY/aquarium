package com.aquarium.models.logics;

public class FishFeeds {
    
}
