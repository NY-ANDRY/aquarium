clear
rm -rf ./target
mvn spring-boot:run