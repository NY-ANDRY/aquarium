fiompiana trondro

poisson:
    nom
    poid initiale
    -race

race:
    nom
    prix de vente
    prix achat
    poid max
    capacite d'augmentation de poid
    besoin proteine
    besoin glucide

    rehefa mahazo proteine sy glucide ilaina de mahazo capacite d'augmentation: (ny ray 50%)

-aliment:
    nom
    prix d'achat
    pourcentage apport proteine (par qtt)
    pourcentage apport glucide

-plat:
    -aliment
    qtt

-fisakafoanana:
    -plat []
    date

tranoTrondro:
    -trondro[]
    -fisakafoanana[]



1- benefice

stocker l'augmentation par jour

* mitovy andro fampidirana

2- insertion date: situation des poisson

